#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCK_PATH  "tpf_unix_sock.server"

int main(void){

    
    int client_sock;
    
    struct sockaddr_un server_sockaddr;

    int len;
    int bytes_rec = 0;

    struct sockaddr_un client_sockaddr;   

    int server_sock;  
              
    server_sock = socket(AF_UNIX, SOCK_STREAM, 0);
    int rc;

    server_sockaddr.sun_family = AF_UNIX;   
    strcpy(server_sockaddr.sun_path, SOCK_PATH); 
    len = sizeof(server_sockaddr);
    
    unlink(SOCK_PATH);
    rc = bind(server_sock, (struct sockaddr *) &server_sockaddr, len);

    int j=0;
    while( j<10){
        for(int i=5;i>0;i--){
            char *dd=(char *)malloc((10+1)*sizeof(char));
            read(client_sock,dd,(10+1));
            printf("%s ",dd);
        }

        int mx=-1;

        printf("\n");

        int i=5;
        while(i>0){
            int *ir=(int *)malloc(sizeof(int));
            read(client_sock,ir,sizeof(int));
            if(mx<*ir){
                mx=*ir;
            }
            printf("%d ",mx);
            i--;
        }
        printf("\n");
        write(client_sock,&mx,sizeof(int));
        j++;
    }

    close(server_sock);
    close(client_sock);
    
    return 0;
}