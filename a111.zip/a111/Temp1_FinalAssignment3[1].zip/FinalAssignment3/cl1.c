#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SERVER_PATH "tpf_unix_sock.server"
#define CLIENT_PATH "tpf_unix_sock.client"
#define DATA "Hello from client"

int main(void){

    int client_sock, rc, len;
    struct sockaddr_un server_sockaddr; 
    struct sockaddr_un client_sockaddr; 

    client_sock = socket(AF_UNIX, SOCK_STREAM, 0);

    client_sockaddr.sun_family = AF_UNIX;   
    strcpy(client_sockaddr.sun_path, CLIENT_PATH); 
    len = sizeof(client_sockaddr);
    
    unlink(CLIENT_PATH);
    rc = bind(client_sock, (struct sockaddr *) &client_sockaddr, len);

    server_sockaddr.sun_family = AF_UNIX;
    strcpy(server_sockaddr.sun_path, SERVER_PATH);
    rc = connect(client_sock, (struct sockaddr *) &server_sockaddr, len);

    int j=0;
    while (j<10){
        for(int i=0; i<5; i++){
            char arr_str[11];
            for(int j=10; j>0; j--){
                arr_str[10-j]=(char)((rand()%(20+6))+35+30);
            }
            arr_str[10]='\0';
            strcpy(arr1[i],arr_str);
        }

        int i=0;
        while( i<5){
            write(client_sock,&i,sizeof(int));
            i++;
        }

        for(int i=5*j; i<(5*j)+10-5; i++){
            write(client_sock,&i,sizeof(int));
        }

        int* IND=(int*)malloc(sizeof(int));
        read(client_sock,IND,sizeof(int));
        printf("Max index: ");
        printf("%d\n",*IND);

        j++;

    }

    close(client_sock);
    
    return 0;
}