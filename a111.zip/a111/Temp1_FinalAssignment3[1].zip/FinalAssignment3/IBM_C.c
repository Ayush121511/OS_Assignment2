#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

char StringList[50][11];


int main(void){
    struct sockaddr_un SOCK_ADDR_C; 
    memset(&SOCK_ADDR_C, 0, sizeof(struct sockaddr_un));
     
    int* buf2;//Strings Index
    int len;

    int SOCK_CLIENT;
    struct sockaddr_un SOCK_ADDR_SERVER;

    memset(&SOCK_ADDR_SERVER, 0, sizeof(struct sockaddr_un));
    
    int rc;
    char buf1[256]; //Actual String

    SOCK_CLIENT = socket(AF_UNIX, SOCK_STREAM, 0);

    strcpy(SOCK_ADDR_C.sun_path, "tpf_unix_sock.client"); 


    SOCK_ADDR_C.sun_family = AF_UNIX;   
    
    unlink("tpf_unix_sock.client");
    len = sizeof(SOCK_ADDR_C);
    rc = bind(SOCK_CLIENT, (struct sockaddr *) &SOCK_ADDR_C, len);
 
    strcpy(SOCK_ADDR_SERVER.sun_path, "tpf_unix_sock.server");


    SOCK_ADDR_SERVER.sun_family = AF_UNIX;
    rc = connect(SOCK_CLIENT, (struct sockaddr *) &SOCK_ADDR_SERVER, len);

    for(int j=0; j<10; j++){

        int i=0;
        while(i<5){
            int j;

            char str[11];
            for(j=0; j<10; j++){
                str[j]=(char)((rand()%26)+65);
            }
            str[10]='\0';
            strcpy(StringList[i],str);
            i++;
            // string_idx[]
        }

        int string_idx[50];

        i=0;
        while(i<5){
            write(SOCK_CLIENT,StringList[i],11);
            i++;
        }

        int i=5*j;
        while( i<5*(j+1)){
            write(SOCK_CLIENT,&i,sizeof(int));
            i++;
        }

        
        int* max_idx=(int*)malloc(sizeof(int));
        read(SOCK_CLIENT,max_idx,sizeof(int));

        printf("MAXIMUM INDEX : ");

        printf("%d\n",*max_idx);

    }

    close(SOCK_CLIENT);
    
    return 0;
}