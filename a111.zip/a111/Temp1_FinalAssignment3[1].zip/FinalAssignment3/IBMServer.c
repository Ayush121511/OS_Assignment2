#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/un.h>

int main(void){
    int len;
    int backlog = 10;
    char buf[256];
    int SOCK_C;
    int* buf2;
    int SOCK_S;
    struct sockaddr_un server_sockaddr;
    memset(&server_sockaddr, 0, sizeof(struct sockaddr_un));
    struct sockaddr_un client_sockaddr;     
    memset(&client_sockaddr, 0, sizeof(struct sockaddr_un));
    memset(buf, 0, 256);                

    SOCK_S = socket(AF_UNIX, SOCK_STREAM, 0);
    int bytes_rec = 0;
    int rc;
    server_sockaddr.sun_family = AF_UNIX; 
    len = sizeof(server_sockaddr);

    strcpy(server_sockaddr.sun_path, "tpf_unix_sock.server"); 
    
    rc = bind(SOCK_S, (struct sockaddr *) &server_sockaddr, len);
    unlink("tpf_unix_sock.server");

    rc = listen(SOCK_S, backlog);
    

    SOCK_C = accept(SOCK_S, (struct sockaddr *) &client_sockaddr, &len);


    len = sizeof(client_sockaddr);
    rc = getpeername(SOCK_C, (struct sockaddr *) &client_sockaddr, &len);
    

    for(int j=0; j<10; j++){
        
            int i=0;
            while(i<5){
                char *dst_buff=(char *)malloc(11*sizeof(char));
                read(SOCK_C,dst_buff,11);
                printf("%s ",dst_buff);
                i++;
            }

            printf("\n");

            int IND_MAX=-1;
            i=0;
            while(i<5){
                int *RINT=(int *)malloc(sizeof(int));
                read(SOCK_C,RINT,sizeof(int));
                if(IND_MAX<*RINT){
                    IND_MAX=*RINT;
                }
                printf("%d ",IND_MAX);
                i++;
            }
            
            printf("\n");
            write(SOCK_C,&IND_MAX,sizeof(int));
    }

    close(SOCK_C);

    close(SOCK_S);
    
    return 0;
}